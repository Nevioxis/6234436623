public class NumericQuestion extends Question
{
    public NumericQuestion(String t) 
    {
        super(t);
    }
    @Override
    public boolean checkAnswer(String response)
    {
        double answerx = Double.parseDouble(super.getAnswer());
        double responsex = Double.parseDouble(response);
        return Math.abs(answerx - responsex) <= 0.01;
    }
}
