import java.util.ArrayList;
public class ChoiceQuestion extends Question
{
    ArrayList<String> choices = new ArrayList<>();
    public ChoiceQuestion(String t)
    {
        super(t);
    }
    public void addChoice(String choice, boolean correct)
    {
        choices.add(choice);
        if(correct) super.setAnswer(choice);
    }
    @Override
    public void display()
    {
        super.display();
        for(String c : choices)
        {
            System.out.printf("%d: %s\n",choices.indexOf(c)+1,c);
        }
    }
    @Override
    public boolean checkAnswer(String response)
    {
        int ch = Integer.parseInt(response);
        return choices.get(ch-1).equals(super.getAnswer());
    }
}
