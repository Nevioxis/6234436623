public class Question 
{
    private String text,answer;
    public Question(String t)
    {
        text = t;
    }
    public Question(){}
    public String getText()
    {
        return text;
    }
    public String getAnswer()
    {
        return answer;
    }
    public void setText(String t)
    {
        text = t;
    }
    public void setAnswer(String a)
    {
        answer = a;
    }
    public boolean checkAnswer(String response)
    {
        return answer.equals(response);
    }
    public void display()
    {
        System.out.println(text);
    }
}
