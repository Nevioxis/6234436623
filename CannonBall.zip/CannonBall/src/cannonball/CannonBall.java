/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cannonball;
/**
 *
 * @author usci
 */
public class CannonBall {
   private double initV;
    private double simS; 
    private double simT; 
    public static final double g = 9.81;
    public CannonBall(double u){
        this.initV = u;
    }
    public void simulatedFlight()
    {
        double v =this.initV;
        simT = 0;
        double deltaS = 0;
        final double deltaT = 0.01;
        int i = 1;
        while (v>=0)
        {
           deltaS = v*deltaT;
           simS += deltaS;
           if (i == 100) {
               System.out.printf("Distance on %.0f sec: %.3f\n",simT,simS);
               i = 0;
           }
           v -= g*deltaT;
           simT += deltaT;
           i++;
        }
        System.out.printf("Final distance: %.3f Total time: %.2f\n",simS,simT);
    }
    public double calculusFlight(double t)
    {
       return -0.5*g*t*t + initV*t;
    }
    public double getSimulatedTime()
    {
       return simT; 
    }
    public double getSimulatedDistance()
    {
       return simS;
    }
}
