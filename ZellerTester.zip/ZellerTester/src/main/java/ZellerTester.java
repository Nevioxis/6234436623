
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class ZellerTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner year = new Scanner(System.in);
        System.out.print("Enter year (e.g., 2012): ");
        int y = year.nextInt();
        Scanner month = new Scanner(System.in);
        System.out.print("Enter month (1-12): ");
        int m = month.nextInt();
        Scanner day = new Scanner(System.in);
        System.out.print("Enter day of the month (1-31): ");
        int d = day.nextInt();
        Zeller date = new Zeller(d,m,y);
        System.out.printf("Day of the week is %s.\n",date.getDayOfWeek().getDay());
    }
    
}
