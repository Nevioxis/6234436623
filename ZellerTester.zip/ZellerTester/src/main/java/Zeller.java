/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author User
 */ 
enum Day{
     SUNDAY("Sunday"), 
     MONDAY("Monday"), 
     TUESDAY("Tuesday"), 
     WEDNESDAY("Wednesday"), 
     THURSDAY("Thursday"), 
     FRIDAY("Friday"), 
     SATURDAY("Saturday");
     private String day;
     Day(String day) {this.day = day;}
     public String getDay(){
         return day;
     }
}
public class Zeller {
    private int dayOfMonth; 
    private int month;
    private int year;
    public Zeller(int d, int m, int y){
        this.dayOfMonth = d;
        this.month = m;
        this.year = y;
    }
        public Day getDayOfWeek(){
         int m;
         switch (month) {
             case 1:
                 m = 13;
                 year-=1;
                 break;
             case 2:
                 m = 14;
                 year-=1;
                 break;
             default:
                 m = month;
                 break;
         }
         int j = year/100;
         int k = year%100;
         int q = dayOfMonth;
         int mm = (m+1)*26/10;
         int kk = k*5/4;
         int jj = j*21/4;
         int h = (q+mm+jj+kk)%7;
         switch (h){
             case 0: return Day.SATURDAY;
             case 1: return Day.SUNDAY;
             case 2: return Day.MONDAY;
             case 3: return Day.TUESDAY;
             case 4: return Day.WEDNESDAY;
             case 5: return Day.THURSDAY;
             case 6: return Day.FRIDAY;
         }
        return null;
         }
     }  
