import java.util.ArrayList;
public class SelfCheckOut implements SimpleQueue
{
    private final ArrayList<Product> products = new ArrayList<>();
    private double amount;
    @Override
    public void enqueue(Object o)
    {
       Product x = (Product) o;
       products.add(x);
       System.out.println(x.getName() + " is added in queue");
    }
    @Override
    public void dequeue() 
    {
        Product p = products.remove(0);
        amount += p.getPrice();
    }
    public double getAmount()
    {
        return amount;
    }
}


