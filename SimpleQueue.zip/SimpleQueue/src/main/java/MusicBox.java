import java.util.ArrayList;
public class MusicBox implements SimpleQueue
{
    private final ArrayList<String> songs = new ArrayList<>();
    @Override
    public void enqueue(Object o)
    {
        songs.add((String) o);
        System.out.println(o + " is added in queue");
    }
    @Override
    public void dequeue() 
    {
        String track = songs.remove(0);
        System.out.println("Now playing " + track);
    }
}


