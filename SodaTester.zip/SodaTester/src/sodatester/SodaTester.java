/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sodatester;

/**
 *
 * @author usci
 */
import java.util.Scanner;
class SodaCan{
    private double height;
    private double radius;
    public static final double piConst = 3.1415926536;
    public SodaCan (double height, double diameter){
        this.height = height;
        this.radius = diameter/2;
    }
    public double getVolume(){
        return piConst*radius*radius*height;
    }
    public double getSurfaceArea(){
        return (2*piConst*radius*height)+(2*piConst*radius*radius);
    }
}
public class SodaTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc1 = new Scanner(System.in);
        System.out.print("Enter height: ");
        double height = sc1.nextDouble();
        Scanner sc2 = new Scanner(System.in);
        System.out.print("Enter diameter: ");
        double radius = sc2.nextDouble();
        SodaCan tester = new SodaCan(height,radius);
        System.out.printf("Volume: %.2f\n",tester.getVolume());
        System.out.printf("Surface area: %.2f\n",tester.getSurfaceArea());
    }
    
}
