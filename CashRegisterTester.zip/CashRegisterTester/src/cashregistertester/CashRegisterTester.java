/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cashregistertester;

/**
 *
 * @author usci
 */
class CashRegister{
    private double totalNonTaxablePrice;
    private double totalTaxablePrice;
    private double money;
    private double taxrate;
    private double tax;
    public CashRegister(double taxrate){
        totalNonTaxablePrice = 0;
        totalTaxablePrice = 0;
        money = 0;
        this.taxrate = taxrate;
        tax = 0;
    }
    public void recordPurchase(double price){
        totalNonTaxablePrice += price;
    }
    public void recordTaxablePurchase(double price){
        totalTaxablePrice += price;
        tax += (price*taxrate/100);
    }
    public double getTotalTax(){
        return tax;
    }
    public void enterPayment(double money){
        this.money = money;
    }
    public double getChange(){
    double change = this.money-(this.totalNonTaxablePrice+this.totalTaxablePrice+this.tax);
    this.money = 0;
    this.totalNonTaxablePrice = 0;
    this.totalTaxablePrice = 0;
    this.tax = 0;
    return change;
    }
}
public class CashRegisterTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CashRegister tester = new CashRegister(7);
        tester.recordPurchase(50);
        tester.recordPurchase(10);
        tester.recordTaxablePurchase(20);
        tester.enterPayment(100);
        System.out.println("Your change is "+tester.getChange());
    }
    
}
