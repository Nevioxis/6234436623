public class Pool extends Terrain
{
    public Pool(String name)
    {
        super(name);
    }
    @Override
    public boolean canMove(Animal animal) 
    {
        return animal instanceof CanSwim;
    }
}

