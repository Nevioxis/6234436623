public class Ground extends Terrain
{
    public Ground(String name)
    {
        super(name);
    }
    @Override
    public boolean canMove(Animal animal) 
    {
        return animal instanceof CanWalk;
    }
}

