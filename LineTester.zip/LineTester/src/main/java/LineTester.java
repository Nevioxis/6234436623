/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class LineTester {


    public static void main(String[] args) {
       Line l1 = new Line(1,-24); 
       Line l2 = new Line(29,5,53,29);   
       System.out.println("Are the two lines equals?: " +l1.equals(l2));
       System.out.println("Are the two lines parallel?: " +l1.isParallel(l2));
       System.out.println("Are the two lines intersect?: " +l1.isIntersect(l2));
       if (!(l1.getIntersectionPoint(l2) == null)){
           System.out.printf("Point of intersection: %.2f,%.2f\n" ,l1.getIntersectionPoint(l2).x,+l1.getIntersectionPoint(l2).y);
       }
    }
    
}
