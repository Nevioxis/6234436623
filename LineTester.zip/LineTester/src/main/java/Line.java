
import java.awt.geom.Point2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Line {
    private double slope;
    private double yIntersection;
    private double xIntersection;
    private boolean isVerticalLine;
    public Line(double x,double y,double m){
        isVerticalLine = false;
        slope = m;
        yIntersection = y-(m*x);
        if (slope != 0) {xIntersection = -(yIntersection/slope);}
    }
    public Line(double x1, double y1, double x2, double y2){
        if (x1-x2 != 0){
            isVerticalLine = false;
            slope = (y1-y2)/(x1-x2);
            yIntersection = y1-(slope*x1);
            if (slope != 0) {xIntersection = -(yIntersection/slope);}
        }
        else {xIntersection = x1; isVerticalLine = true;}
    }
    public Line(double m, double b){
        isVerticalLine = false;
        slope = m;
        yIntersection = b;
        xIntersection = -(yIntersection/slope);
    }
    public Line(double a){
        xIntersection = a;
        isVerticalLine = true;
    }
    public boolean isParallel(Line line){
        return (this.slope == line.slope) && (!this.isVerticalLine || line.isVerticalLine) && (this.isVerticalLine || !line.isVerticalLine);
    }
    public boolean equals(Line line){
        return (this.isParallel(line) && (this.yIntersection == line.yIntersection)) || (this.xIntersection == line.xIntersection);
    }
    public boolean isIntersect(Line line){
        return !(this.isParallel(line));
    }
    public Point2D.Double getIntersectionPoint(Line line){
        if(this.isIntersect(line)){
            double x;
            if (this.isVerticalLine) {x = this.xIntersection;}
            else if (line.isVerticalLine) {x = line.xIntersection;}
            else {x = -(this.yIntersection-line.yIntersection)/(this.slope-line.slope);}
            double y = this.slope*x+this.yIntersection;
            Point2D.Double XYIntersection = new Point2D.Double(x,y);
            return XYIntersection;
        }
        return null;
    }
}
