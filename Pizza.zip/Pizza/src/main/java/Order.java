import java.util.ArrayList;
public class Order 
{
      public static int cntOrder = 0; 
      private final int id;
      private final Customer c;
      private final ArrayList<Pizza> p = new ArrayList<>();
      public Order(Customer cx)
      {
          c = cx;
          cntOrder++;
          id = cntOrder;
      }
      public void addPizza(Pizza px)
      {
          p.add(px);
      }
      public double calculatePayment()
      {
          double total = 0;
          double discount = 1;
          if (c instanceof GoldCustomer)
          {
              GoldCustomer d = (GoldCustomer)  c;
              discount = (100-d.getDiscount())/100;
          }
          for(Pizza px: p)
          {
              total += px.getPrice()*discount;
          }
          return total;
      }
      public String getOrderDetail() 
      {
          String x = Integer.toString(id);
          String str = "Order id : " + x + "\n" + c.toString() + "\n";
          for(Pizza px : p)
          {
              str += (px.toString() + "\n");
          }
          String y = Double.toString(calculatePayment());
          String z = Integer.toString(p.size());
          str += ("Total Pieces : " + z + "\n") + ("Total cost : " + y);
          return str;
      }
}
