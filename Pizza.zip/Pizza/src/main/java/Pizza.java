public class Pizza 
{
    private String name;
    private double price;
    public Pizza(String n,double p)
    {
        name = n;
        price = p;
    }
    @Override
    public String toString()
    {
        return name + " price : " + price;
    }
    public String getName()
    {
        return name;
    }
    public double getPrice()
    {
        return price;
    }
    public void setName(String n)
    {
        name = n;
    }
    public void setPrice(double p)
    {
        price = p;
    }
}
