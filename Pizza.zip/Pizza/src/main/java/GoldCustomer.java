public class GoldCustomer extends Customer
{
    private double discount;
    public GoldCustomer(String n, String t, double d)
    {
        super(n, t);
        discount = d;
    }
    public String toString()
    {
        return super.toString() + " discount : " + discount;
    }
    public double getDiscount()
    {
        return discount;
    }
    public void setDiscount(double d)
    {
        discount = d;
    }
}
