public class Customer 
{
    private String name, tel;
    public Customer (String n,String t)
    {
        name = n;
        tel = t;
    }
    @Override
    public String toString()
    {
        return name + " tel : " + tel;
    }
    public String getName()
    {
        return name;
    }
    public String getTel()
    {
        return tel;
    }
    public void setName(String n)
    {
        name = n;
    }
    public void setTel(String t)
    {
        tel = t;
    }
}
