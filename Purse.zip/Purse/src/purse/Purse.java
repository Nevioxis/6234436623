/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package purse;

import java.util.ArrayList;

/**
 *
 * @author usci
 */
public class Purse {
    private ArrayList<String> coins = new ArrayList<>();
    public Purse(){}
    public void addCoin(String coinName) 
    {
        coins.add(coinName);
    }
    public String toString() 
    {
        String purse = "Purse[";
        int i = 0;
        for (String type : coins)
        {
            if (i == coins.size() -1) {purse += type;}
            else {purse += (type + ",");}
            i++;
        }
        purse += "]";
        return purse;
    }
    public ArrayList<String> reverse()
    {
        ArrayList<String> rCoins = new ArrayList<>();
        for(int i = coins.size()-1;i>=0;i--)
        {
            rCoins.add(coins.get(i));
        }
        return rCoins;
    }
    public void transfer(Purse other) 
    {
        for (String type : this.coins)
        {
            other.coins.add(type);
        }
        this.coins.clear();
    }
    public boolean sameContents(Purse other) {
        if (this.coins.size() == other.coins.size())
        {
            for(int i = 0;i<this.coins.size();i++)
                if(this.coins.get(i) != other.coins.get(i)) {return false;}
            return true;
        }
        else {return false;}
    }
    public boolean sameCoins(Purse other)
    {
        boolean same = false;
        if (this.coins.size() == other.coins.size())
        {
            for(String type : this.coins)
            {
                same = false;
                for(String typex : other.coins)
                {
                    if(type.equals(typex)) 
                   {
                       same = true;
                       break;
                   }
                }
                if (same == false) {return false;}
            }
            return true;
        }
        else {return false;}
    }
}
