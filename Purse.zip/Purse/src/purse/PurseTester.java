/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package purse;

/**
 *
 * @author usci
 */
public class PurseTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Purse purse = new Purse();
        purse.addCoin("Quarter");
        purse.addCoin("Dime");
        purse.addCoin("Nickel");
        purse.addCoin("Dime");
        System.out.println(purse.toString());
        System.out.println(purse.reverse());
        Purse purse2 = new Purse();
        purse2.addCoin("Dime");
        purse2.addCoin("Nickel");
        purse.transfer(purse2);
        System.out.println(purse.toString());
        System.out.println(purse2.toString());
        Purse purse3 = new Purse();
        purse3.addCoin("Nickel");
        purse3.addCoin("Dime");
        purse3.addCoin("Quarter");
        purse3.addCoin("Dime");
        purse.addCoin("Quarter");
        purse.addCoin("Dime");
        purse.addCoin("Nickel");
        purse.addCoin("Dime");
        System.out.println(purse.toString());
        System.out.println(purse3.toString());
        System.out.println(purse.sameContents(purse3));
        System.out.println(purse.sameCoins(purse3));
    }
    
}
