import java.io.FileNotFoundException;
public class TextCountProgram 
{
    public static void main(String[] args) throws FileNotFoundException
    {
        TextAdding txt = new TextAdding("text.txt");
        txt.textAddingFullProcess();
        TextCounter counter = new TextCounter("text.txt");
        System.out.println(counter.ShowAllInfo());
    }
}







