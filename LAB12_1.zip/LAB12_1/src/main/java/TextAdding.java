import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class TextAdding 
{
    private final File file;
    ArrayList<String> text;
    public TextAdding(String f)
    {
        file = new File(f);
        text = new ArrayList<>();
    }
    public void writingText() throws FileNotFoundException
    {
        PrintWriter p = new PrintWriter(file);
        for(String t :text)
        {
            p.println(t);
        }
        p.close();
    }
    public boolean addingText(String x)
    {
        if(x.equals("quit")) return false;
        else
        {
            text.add(x);
            return true;
        }
    }
    public void textAddingFullProcess() throws FileNotFoundException
    {
        Scanner s = new Scanner(System.in);
        boolean n = addingText(s.nextLine());
        while(n)
        {
            s = new Scanner(System.in);
            n = addingText(s.nextLine());
        }
        writingText();
    }
}



