import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class TextCounter 
{
    private final File file;
    public TextCounter(String f)
    {
        file = new File(f);
    }
    private ArrayList<String> getContent() throws FileNotFoundException
    {
        Scanner x = new Scanner(file);
        ArrayList<String> text = new ArrayList<>();
        while(x.hasNext())  text.add(x.nextLine());
        x.close();
        return text;
    }
    public long charactersCounter() throws FileNotFoundException
    {
        ArrayList<String> lines = getContent();
        long character = 0;
         for(String i : lines)
         {
             character += i.length();
         }
        return character;
    }
    public long linesCounter() throws FileNotFoundException
    {
        return getContent().size();
    }
    public long wordsCounter() throws FileNotFoundException
    {
        ArrayList<String> lines = getContent();
        ArrayList<String> words = new ArrayList<>();
        String[] wordsInLine;
        for(String i : lines)
        {
            if(i.contains(" "))
            {
                wordsInLine = i.split(" ");
                words.addAll(Arrays.asList(wordsInLine));
            }
            else words.add(i);
        }
        return words.size();
    }
    public String ShowAllInfo() throws FileNotFoundException
    {
        return "Total characters : " + charactersCounter() + "\nTotal words : " + wordsCounter() + "\nTotal lines : " + linesCounter() + "\n";
    }
}





