public class Secretary extends Employee implements Evaluation
{
    private final int typingSpeed;
    private final int[] score;
    public Secretary(String n, int s, int[] sc,int ts) 
    {
        super(n,s);
        this.typingSpeed = ts;
        score = sc;
    }
    @Override
    public double evaluate() 
    {
        double total = 0;
        for (int i : score) total += i;
        return total;
    }
    @Override
    public char grade(double g)
    {
        if (g >= 90)
        {
            super.setSalary(18000);
            return 'P';
        }
        else return 'F';
    }
}
