public class Subject implements Evaluation {
    private final String subjName;
    private final int[] score;
    public Subject(String s, int[] sc) 
    {
        this.subjName = s;
        score = sc;
    }
    @Override
    public double evaluate() 
    {
        double total = 0;
        double n = 0;
        for (int i : score) 
        {
            total += i;
            n++;
        }
        return total/n;
    }
    @Override
    public char grade(double g)
    {
        if (g >= 70) return 'P';
        else return 'F';
    }
    @Override
    public String toString() 
    {
        return this.subjName;
    }
}
