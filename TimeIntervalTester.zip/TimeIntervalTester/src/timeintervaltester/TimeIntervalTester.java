/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timeintervaltester;
import java.util.Scanner;
class TimeInterval{
    private int startTime;
    private int endTime;
    public TimeInterval(int startTime, int endTime){
        this.startTime = startTime;
        this.endTime = endTime;
    }
    public int getMinutes(){
        return Math.abs(endTime%100-startTime%100);
    }
    public int getHours(){
        return Math.abs(endTime/100-startTime/100)+Integer.signum(Integer.signum(endTime%100-startTime%100)-1);
    }
}
/**
 *
 * @author usci
 */
public class TimeIntervalTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc1 = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int startTime = sc1.nextInt();
        Scanner sc2 = new Scanner(System.in);
        System.out.print("Enter end time: ");
        int endTime = sc2.nextInt();
        TimeInterval tester = new TimeInterval(startTime,endTime);
        System.out.printf("%d hours %d minutes\n",tester.getHours(),tester.getMinutes());
    }
    
}
