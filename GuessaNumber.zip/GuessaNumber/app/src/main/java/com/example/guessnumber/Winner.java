package com.example.guessnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Winner extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);
        Button playAgain = findViewById(R.id.playAgain);
        final TextView win = findViewById(R.id.win);
        win.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Winner.this,"winner winner chicken dinner!".toUpperCase(),Toast.LENGTH_SHORT).show();
            }
        });
        playAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentRestart = new Intent(Winner.this, MainActivity.class);
                startActivity(intentRestart);
            }
        });
    }
}
