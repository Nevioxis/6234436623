package com.example.guessnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainGame extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_game);
        final TextView status = findViewById(R.id.status);
        status.setText("Guess a number from 1-100");
        final GuessNumber game = new GuessNumber();
        final Button guessButton = findViewById(R.id.guessButton);
        final EditText numberInput = findViewById(R.id.numberInput);
            guessButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int guessNumber = Integer.valueOf(numberInput.getText().toString());
                    if (game.compare(guessNumber) == 1) {status.setText("Your guess is too high");}
                    else if (game.compare(guessNumber) == 2) {status.setText("Your guess is too low");}
                    else
                    {
                        Intent intentFinish = new Intent(MainGame.this, Winner.class);
                        startActivity(intentFinish);
                    }
                }
            });
        }
    }
