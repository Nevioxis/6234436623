package com.example.guessnumber;


import java.util.Random;

public class GuessNumber
{
    private int keyNumber;
    public GuessNumber()
    {
        Random num = new Random();
        this.keyNumber = num.nextInt(100)+1;
    }
    public int compare(int guessNumber)
    {
        if (guessNumber == keyNumber) {return 0;}
        else if (guessNumber > keyNumber) {return 1;}
        else {return 2;}
    }
}
