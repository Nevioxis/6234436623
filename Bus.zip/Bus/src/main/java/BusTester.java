import java.util.ArrayList;
public class BusTester 
{
    public static void main(String[] args) 
    {
       ArrayList<Bus> arr = new ArrayList<>();
       arr.add(new Hybrid(45,1200000,Electric.HIGH_VOLTAGE,150,1));
       arr.add(new CNGBus(50,1000000,200,2));
       for (Bus i : arr)
       {
           System.out.println("ID: " + i.getID());
           LiquidFuel j = (LiquidFuel) i;
           System.out.println("Emission Tier: " + j.getEmissionTier());
           System.out.println("Accel: " + i.getAccel());
       }
    }
}




