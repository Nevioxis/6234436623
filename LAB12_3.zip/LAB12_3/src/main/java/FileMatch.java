import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class FileMatch 
{
    ArrayList<AccountRecord> accountRecord;
    ArrayList<TransactionRecord> transactionRecord;
    public FileMatch()
    {
        this.accountRecord = gatheringAccountRecord(readLines("master.txt"));
        this.transactionRecord = gatheringTransactionRecord(readLines("trans.txt"));
        int i = 0;
        for(AccountRecord acc: accountRecord)
        {
            for(TransactionRecord tns : transactionRecord)
            {
                acc.combine(tns);
            }
            accountRecord.set(i, acc);
            i++;
        }
        writeNewMaster();
    }
     private ArrayList<String> readLines(String f) 
    {
        File file = new File(f);
        ArrayList<String> text = new ArrayList<>();
        try (Scanner x = new Scanner(file)) 
        {
            while(x.hasNext())  text.add(x.nextLine());
        }
        catch (FileNotFoundException e) {System.out.println(e);}
        return text;
    }
    private ArrayList<AccountRecord> gatheringAccountRecord(ArrayList<String> acc)
    {
        ArrayList<AccountRecord> accounts = new ArrayList<>();
        String[] text;
        for(String t : acc)
        {
            text = t.split(" ");
            accounts.add(new AccountRecord(Integer.parseInt(text[0]),text[1]+" "+text[2],Double.parseDouble(text[3])));
        }
        return accounts;
    }
    private ArrayList<TransactionRecord> gatheringTransactionRecord(ArrayList<String> tns)
    {
        ArrayList<TransactionRecord> transaction = new ArrayList<>();
        String[] text;
        for(String t : tns)
        {
            text = t.split(" ");
            transaction.add(new TransactionRecord(Integer.parseInt(text[0]),Double.parseDouble(text[1])));
        }
        return transaction;
    }
    private void  writeNewMaster()
    {
        try(RandomAccessFile raf = new RandomAccessFile("newMaster.dat","rw"))
        {
            for(AccountRecord acc: accountRecord)
          {
              raf.writeInt(acc.getAcctNo());
              raf.writeBytes(" "+acc.getName()+(" ".repeat(30-acc.getName().length()))+" ");
              raf.writeDouble(acc.getBalance());
              raf.writeBytes(" ");
              raf.writeInt(acc.getTransCnt());
              raf.writeBytes("\n");
          }
        }
        catch (FileNotFoundException e) {System.out.println(e);}
        catch (IOException e) {System.out.println(e);}
     }
}
