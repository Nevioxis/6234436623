public class AccountRecord 
{
    private final int acctNo;
    private final String name;
    private double balance;
    private int transCnt = 0; 
    public AccountRecord (int acctNo, String name, double balance) 
    {
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
    }
    public int getAcctNo() { return acctNo; }
    public String getName() { return name; }
    public double getBalance(){ return balance; }
    public int getTransCnt() { return transCnt; }
    public void combine(TransactionRecord t)
    {
        if(t.getAccountNumber() == acctNo)
        {
            balance += t.getTransactionAmount();
            transCnt++;
        }
    }
}


