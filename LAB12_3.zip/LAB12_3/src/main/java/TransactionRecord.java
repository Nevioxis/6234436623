public class TransactionRecord 
{
    private int accountNumber;
    private double transactionAmount;
    public TransactionRecord(int accNo, double tnsAmt)
    {
        this.accountNumber = accNo;
        this.transactionAmount = tnsAmt;
    }
    public int getAccountNumber()
    {
        return accountNumber;
    }
    public void setAccountNumber(int accNo)
    {
        accountNumber = accNo;
    }
    public double getTransactionAmount()
    {
        return transactionAmount;
    }
    public void setTransactionAmount(double tnsAmt)
    {
        transactionAmount = tnsAmt;
    }
}


