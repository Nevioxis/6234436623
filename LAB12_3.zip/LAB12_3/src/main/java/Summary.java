import java.io.*;
import java.util.ArrayList;
public class Summary 
{
    public static void main(String[] args) 
    {
        FileMatch x = new FileMatch();
        ArrayList<AccountRecord> accountRecord = new ArrayList<>();
        double total = 0;
        int nonTransaction = 0;
        int acc = 0;
        long seeker = 36;
        try(RandomAccessFile raf = new RandomAccessFile("newMaster.dat","rw"))
        {
          while(seeker < raf.length()) 
          {
              acc++;
              raf.seek(seeker);
              total += raf.readDouble();
              seeker += 9;
              raf.seek(seeker);
              if(raf.readInt() == 0) nonTransaction++;
              seeker+=41;
          }
        }
        catch (FileNotFoundException e) {System.out.println(e);}
        catch (IOException e) {System.out.println(e);}
        System.out.printf("Total Account Record : %d\nTotal balance : %.1f\nNo transaction : %d account.\n",acc,total,nonTransaction);
     }
}



