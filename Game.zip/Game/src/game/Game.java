/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author usci
 */

public class Game {
    public Game(){}
    private String RpsTransfer(int choice)
    {
        switch (choice) {
            case 0: return "ROCK";
            case 1: return "PAPER";
            case 2: return "SCISSORS";
        }
        return null;
    }
    private int PlayerTurn()
    {
        Scanner userInput = new Scanner(System.in);
        int choice = -1;
        while (!(choice == 0 || choice == 1 || choice == 2)){
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            while(!userInput.hasNextInt()) {
                String t = userInput.next();
                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            }
            choice = userInput.nextInt();
        }
        System.out.println("You enter: "+RpsTransfer(choice));
        return choice;
    }
    private int CpuTurn()
    {
        Random CpuInput = new Random();
        int cpuChoice = CpuInput.nextInt(3);
        System.out.println("Computer: "+RpsTransfer(cpuChoice));
        return cpuChoice;
    }
    private int WinCondition(int p,int c){
        if (p == c) return 0;
        else if ((p == 0 && c == 2) || (p == 1 && c == 0) || (p == 2 && c == 1)) return 1;
        else if ((c == 0 && p == 2) || (c == 1 && p == 0) || (c == 2 && p == 1)) return 2;
        return -1;
    }
    public void play(){
        int playerWin = 0;
        int comWin = 0;
        while (Math.abs(playerWin-comWin) < 2){
        int player = PlayerTurn();
        int com = CpuTurn();
        int result = WinCondition(player,com);
        switch (result) {
            case 0 : 
                System.out.println("It's a tie.");
                break;
            case 1 : 
                System.out.println("You win!");
                playerWin += 1;
                break;
            case 2 : 
                System.out.println("You lose!");
                comWin += 1;
                break;
        }       
        }
        if (playerWin > comWin) 
        {
            System.out.printf("----------------------------------------\nCongrats! You win.\nUser Score: %d\nComputer score: %d\n",playerWin,comWin);
        }
        else 
        {
            System.out.printf("----------------------------------------\nToo bad! You lose.\nUser Score: %d\nComputer score: %d\n",playerWin,comWin);
        }
    }
}
