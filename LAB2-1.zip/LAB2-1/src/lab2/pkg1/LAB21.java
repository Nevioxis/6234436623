/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2.pkg1;
import java.awt.Rectangle;
import java.util.Random;
public class LAB21 {

    public static void main(String[] args) 
    {
    Random xr1 = new Random();
    Random yr1 = new Random();
    Random wr1 = new Random();
    Random hr1 = new Random();
    Rectangle r1 = new Rectangle(xr1.nextInt(50)+1,yr1.nextInt(50)+1,wr1.nextInt(50)+1,hr1.nextInt(50)+1);
    Random xr2 = new Random();
    Random yr2 = new Random();
    Random wr2 = new Random();
    Random hr2 = new Random();
    Rectangle r2 = new Rectangle(xr2.nextInt(50)+1,yr2.nextInt(50)+1,wr2.nextInt(50)+1,hr2.nextInt(50)+1);
    System.out.println(r1);
    System.out.println(r2);
    System.out.println("Is the intersected rectangle empty?:"+r1.intersection(r2).isEmpty());
    }
    
}
