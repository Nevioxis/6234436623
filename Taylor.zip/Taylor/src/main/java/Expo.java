public class Expo extends Taylor
{
    public Expo(int k, double x) 
    {
        super(k, x);
    }
    @Override
    public void printValue() 
    {
         System.out.println("Value from Math.exp() is " + Math.exp(super.getValue()));
         System.out.println("Approximated value is " + getApprox());
    }
    @Override
    public double getApprox() 
    {
        double a = 0;
        for(int i = 0;i<=super.getIter();i++)
        {
            a += ((Math.pow(super.getValue(), i)) / super.factorial(i));
        }
        return a;
    }
}
