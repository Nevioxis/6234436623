public class Cosine extends Taylor
{
    public Cosine(int k, double x) 
    {
        super(k, x);
    }
    @Override
    public void printValue() 
    {
         System.out.println("Value from Math.cos() is " + Math.cos(super.getValue()));
         System.out.println("Approximated value is "  + getApprox());
    }
    @Override
    public double getApprox() 
    {
        double a = 0;
        for(int i = 0;i<=super.getIter();i++)
        {
            a+=(Math.pow(super.getValue(), (2*i))*Math.pow(-1,i)/super.factorial((2*i)));
        }
        return a;
    }
}
