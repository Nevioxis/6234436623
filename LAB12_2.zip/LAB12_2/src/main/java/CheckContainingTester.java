public class CheckContainingTester {
    public static void main(String[] args) 
    {
        CheckContaining.CheckContainingFullProcess();
    }
    
}


