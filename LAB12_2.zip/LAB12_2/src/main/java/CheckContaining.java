import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class CheckContaining 
{
    private ArrayList<String> wordlist;
    ArrayList<String> wordsNotContain;
    String text;
    public CheckContaining() 
    {
        wordlist = new ArrayList<>();
        Scanner x = null;
        text = "";
        wordsNotContain = new ArrayList<>();
        File file; 
        try
        {
            file = new File("wordlist.txt");
            x = new Scanner(file);
            while(x.hasNext())  wordlist.add(x.nextLine());
        }
        catch (FileNotFoundException e)
         {
             System.out.println(e);
         }
        finally
        {
            if(x != null) x.close();
        }
        wordsNotContain(text);
    }
    public CheckContaining(String txt) 
    {
        wordlist = new ArrayList<>();
        Scanner x = null;
        text = txt;
        wordsNotContain = new ArrayList<>();
        File file;
        try
        {
            file = new File("wordlist.txt");
            x = new Scanner(file);
            while(x.hasNext())  wordlist.add(x.nextLine());
        }
        catch (FileNotFoundException e)
         {
             System.out.println(e);
         }
        finally
        {
            if(x != null) x.close();
        }
        wordsNotContain(text);
    }
    public CheckContaining(String f,String txt) 
    {
        wordlist = new ArrayList<>();
        Scanner x = null;
        text = txt;
        wordsNotContain = new ArrayList<>();
        File file;
        try
        {
            file = new File(f);
            x = new Scanner(file);
            while(x.hasNext())  wordlist.add(x.nextLine());
        }
        catch (FileNotFoundException e)
         {
             System.out.println(e);
         }
        finally
        {
            if(x != null) x.close();
        }
        wordsNotContain(text);
    }
    private void wordsNotContain(String n)
    {
        String[] words = n.split(" ");
        for(String w: words)
        {
            if(!wordlist.contains(w) && !wordlist.contains(w.toLowerCase())) wordsNotContain.add(w);
        }
        if(wordsNotContain.isEmpty()) wordsNotContain.add("N/A");
    }
    public static void CheckContainingFullProcess()
    {
        Scanner txt = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        CheckContaining chk = new CheckContaining(txt.nextLine());
        System.out.println(chk.toString());
    }
    @Override
    public String toString()
    {
        String i = "Words not contained: \n";
        for(String x:wordsNotContain)
        {
            i += (x+"\n");
        }
        return i;
    }
    public void SetText(String x)
    {
        text = x;
    }
    public String getText()
    {
        return text;
    }
    public ArrayList<String> getWordsNotContain()
    {
        return wordsNotContain;
    }
}












