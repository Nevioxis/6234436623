/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterprinter;

/**
 *
 * @author usci
 */
class Letter{
    private String sender;
    private String reciever;
    private String letterText;
    public Letter(String from, String to){
        sender = from;
        reciever = to;
        letterText = "";
    }
    public void addLine(String line){
        letterText += (line+"\n");
    }
    public String getText(){
        return "Dear "+reciever+":\n\n"+letterText+"\nSincerely,\n\n"+sender;
    }
}
public class LetterPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Letter printer = new Letter("Clarissa","Jade");
        printer.addLine("We must find Simon quickly.");
        printer.addLine("He might be in danger.");
        System.out.println(printer.getText());
    }
    
}
