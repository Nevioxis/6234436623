public class Truck extends Car
{
    private final double M_weight;
    private double weight;
    public Truck(double g, double e, double mw, double w)
    {
        super(g,e);
        M_weight = mw;
        weight = w;
        if (weight > M_weight) weight = M_weight;
    }
    @Override
    public void drive(double distance)
    {
        if(weight < 1) super.drive(distance);
        else if (weight < 10 && weight >= 1) super.drive(distance*1.1);
        else if (weight < 20 && weight >= 10) super.drive(distance*1.2);
        else super.drive(distance*1.3);
    }
}
