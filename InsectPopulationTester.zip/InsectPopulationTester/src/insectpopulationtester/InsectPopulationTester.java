/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insectpopulationtester;

/**
 *
 * @author usci
 */
class  InsectPopulation {
    private double popularity;
    public InsectPopulation(double popularity) {
        this.popularity = popularity;
    }
    public void breed(){
        popularity *= 2;
    }
    public void spray(){
        popularity *= 0.9;
    }
    public double getNumInsect(){
        return popularity;
    }
}
public class InsectPopulationTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InsectPopulation test = new InsectPopulation(10);
       test.breed();
       test.spray();
       System.out.println("Number of insects: "+test.getNumInsect());
       test.breed();
       test.spray();
       System.out.println("Number of insects: "+test.getNumInsect());
       test.breed();
       test.spray();
       System.out.println("Number of insects: "+test.getNumInsect());
    }
    
}
