/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class MainCityGrid {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        CityGrid manwalk = new CityGrid(10);
        int steps = 0;
        double sumsteps = 0;
        int maxsteps = 0;
        for (int i = 1;i<=10000;i++)
        {
            while(manwalk.isInCity() && steps < 1000)
            {
                manwalk.walk();
                steps+=1;
            }
            manwalk.reset();
            if (steps > maxsteps) {maxsteps = steps;}
            sumsteps += steps;
            steps = 0;
        }
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n",sumsteps/10000);
        System.out.printf("Maximum number of steps that a person can take and is still in the city: %d\n",maxsteps);
    } 
}
