
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class CityGrid {
    private int xCoor; 
    private int yCoor;
    private int gridSize;
    private int defaultXCoor;
    private int defaultYCoor;
    public CityGrid(int s)
    {
        this.gridSize = s;
        this.xCoor = s/2;
        this.yCoor = s/2;
        this.defaultXCoor = this.xCoor;
        this.defaultYCoor = this.yCoor;
    }
    public void walk() 
    {
        Random d = new Random();
        int direction = d.nextInt(4);
        switch (direction) 
        {
            case 0: 
                xCoor+=1;
                break;
            case 1: 
                xCoor-=1;
                break;
            case 2: 
                yCoor+=1;
                break;
            case 3: 
                yCoor-=1;
                break;
        }
    }
    public boolean isInCity()
    {
        return (xCoor >= 0 && xCoor <= gridSize) && (yCoor >= 0 && yCoor <= gridSize);
    } 
    public void reset() 
    {
        this.xCoor = this.defaultXCoor;
        this.yCoor = this.defaultYCoor;
    } 
    
    }
