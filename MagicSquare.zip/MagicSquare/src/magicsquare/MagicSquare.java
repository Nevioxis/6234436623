/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicsquare;

/**
 *
 * @author usci
 */
public class MagicSquare {
    private int k;
    int[][] sq;
    public String toString()
    {
        String x = "";
        for(int i = 0;i<k;i++)
        {
            for(int j = 0;j<k;j++)
            {
                if  (sq[i][j] < 10)  {x += (sq[i][j]+"  ");}
                else {x += (sq[i][j]+" ");}
            }
            x += "\n";
        }
        return x;
    }
    public MagicSquare(int k)
    {
        this.k = k;
        sq = new int[k][k];
        for(int i = 0;i<k;i++)
        {
            for(int j = 0;j<k;j++)
            {
                sq[i][j] = 0;
            }
        }
        sq[k-1][((k+1)/2)-1] = 1;
        int x = 2;
        int i = 0;
        int j = ((k+1)/2);
        while (x<=k*k)
        {
            if (i == k-1 && j == k-1) {sq[i][j] = x; i=k-2;  j=k-1;  x++; continue;}
            sq[i][j] = x;
            i++;
            j++;
            if (i > k-1) {i=0;}
            if (j > k-1) {j=0;}
            if (sq[i][j] != 0)
            {
                    i-=2;
                    j-=1;
                    if (i > k-1 || i<0) {i=0;}
                    if (j > k-1 || j<0) {j=0;}
            } 
            x+=1;
        }
    }
    
}
