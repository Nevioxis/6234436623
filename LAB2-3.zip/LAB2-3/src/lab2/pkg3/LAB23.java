/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2.pkg3;
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 *
 * @author usci
 */
public class LAB23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    GregorianCalendar cal = new GregorianCalendar();
    cal.add(cal.DAY_OF_MONTH,100);
    System.out.println(cal.get(cal.DAY_OF_WEEK)+" "+cal.get(cal.DAY_OF_MONTH)+" "+cal.get(cal.MONTH)+" "+cal.get(cal.YEAR));
    GregorianCalendar birthdate = new GregorianCalendar(2000,Calendar.SEPTEMBER, 2);
    birthdate.add(birthdate.DAY_OF_MONTH,10000);
    System.out.println(birthdate.get(birthdate.DAY_OF_WEEK)+" "+birthdate.get(birthdate.DAY_OF_MONTH)+" "+birthdate.get(birthdate.MONTH)+" "+birthdate.get(birthdate.YEAR));
    }
    
}
